package com.cg.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CapstoreController {
    
    @RequestMapping("/home")
    public String showHomePage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="home";
        return view;
    }
    
    @RequestMapping("/Electronics")
    public String showElectronicsPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="electronics";
        return view;
    }
    
    @RequestMapping("/Clothing")
    public String showClothingPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="clothing";
        return view;
    }
    
    @RequestMapping("/Furniture")
    public String showFurniturePage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="furniture";
        return view;
    }
    
    @RequestMapping("/Books")
    public String showBooksPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="books";
        return view;
    }
    
}