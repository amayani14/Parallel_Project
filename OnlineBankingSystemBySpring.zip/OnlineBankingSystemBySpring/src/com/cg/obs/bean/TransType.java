package com.cg.obs.bean;

public enum TransType{
	Debit, Credit
}