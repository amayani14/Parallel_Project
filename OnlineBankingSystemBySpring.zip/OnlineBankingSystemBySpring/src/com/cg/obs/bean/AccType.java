package com.cg.obs.bean;

public enum AccType{
	Saving, Current;
}
