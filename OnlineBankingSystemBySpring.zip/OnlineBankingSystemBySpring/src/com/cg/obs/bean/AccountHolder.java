package com.cg.obs.bean;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="accHolder_spring")
public class AccountHolder {

	@Id
	@Column(length=14)
	private String userName;
	@NotEmpty(message="Value Required for First Name")
	@Column(length=14)
	private String fName;
	@NotEmpty(message="Value Required for Last Name")
	@Column(length=14)
	private String lName;
	@NotEmpty(message="Value Required for Date of Birth")
	@Pattern(regexp="^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]|"
			+ "(?:Jan|Mar|May|Jul|Aug|Oct|Dec)))\\1|"
			+ "(?:(?:29|30)(\\/|-|\\.)(?:0?[1,3-9]|1[0-2]|"
			+ "(?:Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec))\\2))"
			+ "(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)"
			+ "(?:0?2|(?:Feb))\\3(?:(?:(?:1[6-9]|[2-9]\\d)?"
			+ "(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|"
			+ "[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|"
			+ "1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9]|"
			+ "(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep))|"
			+ "(?:1[0-2]|(?:Oct|Nov|Dec)))\\4(?:(?:1[6-9]|"
			+ "[2-9]\\d)?\\d{2})$",
			message="Invalid Date Entered")
	@Column(length=14)
	private String DOB;
	@NotEmpty(message="Value Required for Last Name")
	@Size(min=4 , max=4, message="Should only have 4 characters")
	@Pattern(regexp="[0-9]{4}", message="Should contain only numbers")
	@Column(length=14)
	private String pin;
	@OneToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private Account account;
	
	public AccountHolder() {
		super();
	}
	public AccountHolder(String fName, String lName,
			String userName, String pin, LocalDate DOB,Double balance,
			String accType) {
		super();
		this.account = new Account(NumberGenerator.getAccNo(),accType,balance);
		this.fName = fName;
		this.lName = lName;
		this.userName = userName;
		this.pin = pin;
		this.DOB = DOB.toString();//.toString();
	}
	public String getAccNo() {
		return account.getAccNo();
	}
	public void setAccNo() {
		account.setAccNo();
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		this.DOB = dOB;
	}
	public String getOpenDate() {
		return account.getOpenDate();
	}
	public void setOpenDate(String openDate) {
		account.setOpenDate(openDate);
	}
	public double getBalance() {
		return account.getBalance();
	}
	public void setBalance(double balance) {
		account.setBalance(balance);
	}
	public String getAccType() {
		return account.getAccType();
	}
	public void setAccType(String accType) {
		account.setAccType(accType);
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public List<Transaction> getTransactions() {
		return account.getTransactions();
	}
	public void setTransactions(Transaction transaction) {
		account.setTransactions(transaction);
	}

	@Override
	public String toString() {
		return "AccountHolder [FirstName= " + fName + "\n LastName= " + lName
				+ "\n UserName= " + userName + "\n DOB= " + DOB + "\n PIN= " + pin
				+ "\n Account= " + account + "]";
	}

	
}
