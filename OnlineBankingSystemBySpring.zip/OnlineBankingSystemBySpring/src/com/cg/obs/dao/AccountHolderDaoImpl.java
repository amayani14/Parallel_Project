package com.cg.obs.dao;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.AccountHolder;
import com.cg.obs.bean.TransType;
import com.cg.obs.bean.Transaction;
import com.cg.obs.exception.BankingException;

@Repository
public class AccountHolderDaoImpl implements AccountHolderDao{	
	
	AccountHolder accHolder = null;
	Map<String, AccountHolder> accounts = null;
	
	@PersistenceContext		
	private EntityManager em;	
	
	@Override
	public String createAccount(AccountHolder accHolder) {
		
		Transaction transaction = new Transaction
				(String.valueOf((int)(Math.random()*2147483647)),
					LocalDateTime.now(), new BigInteger(accHolder.getAccNo()),
					TransType.Credit, accHolder.getBalance(), accHolder.getBalance());
		accHolder.setTransactions(transaction);
		em.persist(accHolder);
		return accHolder.getAccNo();
		
	}
	

	@Override
	public double showBalance(String userName, String pin) throws BankingException{
		
		try{
		AccountHolder account = em.find(AccountHolder.class, userName);
		if(account.getPin().equals(pin))
		{
			return account.getBalance();
		}
		else
		{
			throw new BankingException("Incorrect PIN!");
		}
		}catch(NullPointerException e) {
			throw new BankingException("Account not found!");
		}
	}
	
	

	@Override
	public double deposit(String userName, String pin, double amount) throws BankingException {
		
		try{
			AccountHolder account = em.find(AccountHolder.class, userName);
			if(account.getPin().equals(pin))
			{
				account.setBalance(account.getBalance() + amount);
				Transaction transaction = new Transaction
					(String.valueOf((int)(Math.random()*2147483647)),
						LocalDateTime.now(), new BigInteger(account.getAccNo()),
						TransType.Credit, amount, account.getBalance());
				account.setTransactions(transaction);
				return account.getBalance();
			}
			else
			{
				throw new BankingException("Incorrect PIN!");
			}
		}catch(NullPointerException e) {
			throw new BankingException("Account not found!");
		}
	}

	@Override
	public double withdraw(String userName, String pin, double amount) throws BankingException {
		
		try{
			AccountHolder account = em.find(AccountHolder.class, userName);
			if(account.getPin().equals(pin))
			{
				account.setBalance(account.getBalance() - amount);
				Transaction transaction = new Transaction
				(String.valueOf((int)(Math.random()*2147483647)),
					LocalDateTime.now(), new BigInteger(account.getAccNo()),
					TransType.Debit, amount, account.getBalance());
				account.setTransactions(transaction);
				return account.getBalance();
			}
			else
			{
				throw new BankingException("Incorrect PIN!");
			}
		}catch(NullPointerException e) {
			throw new BankingException("Account not found!");
		}
	}

	@Override
	public double fundTransfer(String userName, String pin, String targetAccNo,
			double amount) throws BankingException {
		
		AccountHolder source = null;
				Account	target = null;
		
			source = em.find(AccountHolder.class, userName);
			if(source != null)
			{
				if(source.getPin().equals(pin))
				{
					double balance = source.getBalance();
					if(balance >= amount)
					{
						/*TypedQuery<AccountHolder> ac = em.createQuery
							("from AccountHolder where ACCOUNT_ACNO= :acn",
									AccountHolder.class);
						ac.setParameter("acn", targetAccNo);
						target = ac.getSingleResult();*/
						target = em.find(Account.class, targetAccNo);
						if(target != null)
						{
							source.setBalance(source.getBalance() - amount);
							target.setBalance(target.getBalance() + amount);
							String transId =String.valueOf((int)(Math.random()*2147483647)); 
							Transaction transaction1 = new Transaction
							(transId, LocalDateTime.now(), new BigInteger(target.getAccNo()),
								TransType.Debit, amount, source.getBalance());
							Transaction transaction2 = new Transaction
							(transId, LocalDateTime.now(), new BigInteger(source.getAccNo()),
								TransType.Credit, amount, target.getBalance());
							source.setTransactions(transaction1);
							target.setTransactions(transaction2);
							em.persist(transaction1);
							em.persist(transaction2);
							
							return source.getBalance();
						}
						else
						{
							throw new BankingException("Target Account not found!");
						}
					}
					else
					{
						throw new BankingException("Insufficient Balance!");
					}
				}
				else
				{
					throw new BankingException("Incorrect PIN!");
				}
			}
			else
			{
				throw new BankingException("Source Account not found!");
			}
	}

	@Override
	public List<Transaction> printTransactions(String userName, String pin) throws BankingException {
	
		AccountHolder account = em.find(AccountHolder.class, userName);	
		if(account != null)	
		{
			if(account.getPin().equals(pin))
			{
				return account.getTransactions();
			}
			else
			{
				throw new BankingException("Incorrect PIN!");
			}
		}
		else
		{
			throw new BankingException("Account not found!");
		}
	}


	@Override
	public List<AccountHolder> fetchAllAccounts() {
		
		TypedQuery<AccountHolder> query = em.createQuery("from AccountHolder",AccountHolder.class);
		List<AccountHolder> accounts = query.getResultList();
		return accounts;
	}

}
