package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CapstoreController {
    
    @RequestMapping("/home")
    public String showHomePage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="home";
        return view;
    }
    
    @RequestMapping("/Electronics")
    public String showElectronicsPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="electronics";
        return view;
    }
    
    @RequestMapping("/Clothing")
    public String showClothingPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="clothing";
        return view;
    }
    
    @RequestMapping("/Furniture")
    public String showFurniturePage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="furniture";
        return view;
    }
    
    @RequestMapping("/Books")
    public String showBooksPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="books";
        return view;
    }
    
    
    @RequestMapping("/Mobile")
    public String showMobilePage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="mobile";
        return view;
    }
    
    @RequestMapping("/Chair")
    public String showChairPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="chair";
        return view;
    }
    
    @RequestMapping("/Jackets")
    public String showJacketsPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="jacket";
        return view;
    }
    
    @RequestMapping("/Fiction")
    public String showFictionPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="fiction";
        return view;
    }
    
    //Aman Agnihotri
    
    @RequestMapping("/Redmi")
    public String showRedmiPage(Model model,HttpServletRequest request)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="Redmi";
		List<String> list=new ArrayList<>();
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		list.add("5");
		ServletContext context=request.getServletContext();
		context.setAttribute("items", list);
		
		List<String> list2=new ArrayList<>();
		list2.add("*");
		list2.add("**");
		list2.add("***");
		list2.add("****");
		list2.add("*****");
		ServletContext context1=request.getServletContext();
		context1.setAttribute("feed", list2);
        return view;
    }
    
    @RequestMapping("/jack")
    public String showJacketPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="Jacket";
        return view;
    }
    
    @RequestMapping("/chairs")
    public String showChairsPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="Chair";
        return view;
    }
    
    @RequestMapping("/Buk")
    public String showBukPage(Model model)
    {
        //model.addAttribute("message","WElcome to HomePage");
        String view="ncert";
        return view;
    }
    
}