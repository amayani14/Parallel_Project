package pagebean;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FormPageFactory
{
	WebDriver driver;
	
	@FindBy(how=How.NAME, using="txtUName")
	@CacheLookup
	WebElement uname;
	
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement password;
	
	
	@FindBy(how=How.CSS, using="#txtConfPassword")
	@CacheLookup
	WebElement cpass;
	
	@FindBy(how=How.XPATH, using="//*[@id=\"txtFirstName\"]")
	@CacheLookup
	WebElement fname;
	
	@FindBy(how=How.XPATH, using="//*[@id=\"txtLastName\"]")
	@CacheLookup
	WebElement lname;
	
	@FindBy(how=How.NAME, using="rbMale")
	@CacheLookup
	WebElement gen;
	
	@FindBy(how=How.NAME, using="DtOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(how=How.CSS, using="#txtEmail")
	@CacheLookup
	WebElement email;
	
	
	@FindBy(how=How.NAME, using="Address")
	@CacheLookup
	WebElement address;
	
	 @FindBy(name="City")
	    @CacheLookup
	    WebElement city;
	 
	 @FindBy(how=How.CSS,using="#txtPhone")
	    @CacheLookup
	    WebElement phonenumber;
	 
	 @FindBy(name="chkHobbies")
	    @CacheLookup
	    WebElement hobbies;
	 
	 @FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[13]/td/input")
	    @CacheLookup
	    WebElement submit;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUname() {
		return uname;
	}

	public void setUname(String username) {
		uname.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String pass) {
		password.sendKeys(pass);
	}

	public WebElement getCpass() {
		return cpass;
	}

	public void setCpass(String cpassword) {
		cpass.sendKeys(cpassword);
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String firstname) {
		fname.sendKeys(firstname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lastname) {
		lname.sendKeys(lastname);
	}

	public WebElement getGender() {
		return gen;
	}

	public void setGender(String ge) {
		
		List<WebElement> gen = driver.findElements(By.name("gender"));
        for(WebElement webElement :gen)
       {
        String radioSelection;
        radioSelection = webElement.getAttribute("value").toString();
        if(radioSelection.equals(ge))
        {
            webElement.click();
        }
                                    
        try
        {
            Thread.sleep(500);
        }
        catch(InterruptedException ex)
        {
            System.out.println(ex.getMessage());
        }   
        }
		
		
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dateob) {
		dob.sendKeys(dateob);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String emails) {
		email.sendKeys(emails);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String add) {
		address.sendKeys(add);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String c) {
		
		 Select drpCity = new Select(city);
	        drpCity.selectByVisibleText(c);
	}

	public WebElement getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String pnumber) {
		phonenumber.sendKeys(pnumber);
	}

	public WebElement getHobbies() {
		return hobbies;
	}

	public void setHobbies(String h1, String h2 ) {

        
List<WebElement> hobbies = driver.findElements(By.name("chkHobbies"));
        
        for(WebElement webElement : hobbies)
        {
                String checkSelection;
                checkSelection = webElement.getAttribute("value").toString();
                if(checkSelection.equals(h1)||checkSelection.equals(h2))
                {
                    webElement.click();
                }
                                            
                try
                {
                    Thread.sleep(500);
                }
                catch(InterruptedException ex)
                {
                    System.out.println(ex.getMessage());
                }   
        }      
    }
    
	

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}
	
	 public FormPageFactory(WebDriver driver)
	    {
	        this.driver =driver;
	        //This initElements method will create all WebElements
	        PageFactory.initElements(driver, this);
	       
	    }
	 
	 
	
	
	
	
	
	
	

}
