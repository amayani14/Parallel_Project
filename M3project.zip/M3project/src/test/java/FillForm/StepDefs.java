package FillForm;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pagebean.FormPageFactory;

public class StepDefs {
	WebDriver  driver;
	FormPageFactory pagefactoryobj;


@Given("^User is on the registration page$")
public void user_is_on_the_registration_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\amayani\\Desktop\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///C:/Users/amayani/Downloads/WorkingWithForms.html");
	driver.manage().window().maximize();
	Thread.sleep(5000);
    
}

@When("^User fills all the details correctly$")
public void user_fills_all_the_details_correctly() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 pagefactoryobj= new FormPageFactory(driver);

	
	pagefactoryobj.setUname("Avi");
	pagefactoryobj.setPassword("avinash");
	pagefactoryobj.setCpass("avinash");
	pagefactoryobj.setFname("Avinas");
	pagefactoryobj.setLname("Mayani");
	pagefactoryobj.setGender("Male");
	pagefactoryobj.setDob("25-12-2014");
	pagefactoryobj.setEmail("amah@gmail.com");
	pagefactoryobj.setAddress("Airoli");
	pagefactoryobj.setCity("Mumbai");
	pagefactoryobj.setPhonenumber("7060289247");
	pagefactoryobj.setHobbies("Music", "Reading");
	pagefactoryobj.setSubmit();
	
	
	
	
	
	
	
    
}

@Then("^Alert message got displayed$")
public void alert_message_got_displayed() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Alert alert=driver.switchTo().alert();
	System.out.println("The alert message is : " + alert.getText());
	alert.accept();
	Thread.sleep(5000);
   
}


@When("^user fills details incorrectly$")
public void user_fills_details_incorrectly() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	 pagefactoryobj= new FormPageFactory(driver);

		
		pagefactoryobj.setUname("Avi");
		pagefactoryobj.setPassword("avinash");
		pagefactoryobj.setCpass("avinash");
		pagefactoryobj.setFname("");
		pagefactoryobj.setLname("");
		pagefactoryobj.setGender("Male");
		pagefactoryobj.setDob("25-12-2014");
		pagefactoryobj.setEmail("amah@gmail.com");
		pagefactoryobj.setAddress("Airoli");
		pagefactoryobj.setCity("Mumbai");
		pagefactoryobj.setPhonenumber("70289247");
		pagefactoryobj.setHobbies("Music", "Reading");
		pagefactoryobj.setSubmit();
		
  
}

@Then("^it shows alert message$")
public void it_shows_alert_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
}


}
